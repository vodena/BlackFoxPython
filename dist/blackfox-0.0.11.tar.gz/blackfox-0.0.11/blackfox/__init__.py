# coding: utf-8

# flake8: noqa

"""
    blackfox

    Module *blackfox* exposes *BlackFox*, a class with all the optimization methods and controls.

"""


from __future__ import absolute_import

# import apis into sdk package
from blackfox_restapi.api.data_set_api import DataSetApi
from blackfox_restapi.api.network_api import NetworkApi
from blackfox_restapi.api.optimization_api import OptimizationApi
from blackfox_restapi.api.prediction_api import PredictionApi
from blackfox_restapi.api.recurrent_optimization_api import RecurrentOptimizationApi
from blackfox_restapi.api.training_api import TrainingApi
from blackfox_restapi.rest import ApiException

# import ApiClient
from blackfox_restapi.api_client import ApiClient
from blackfox_restapi.configuration import Configuration
# import models into sdk package
from blackfox_restapi.models.convergency_criterion import ConvergencyCriterion
from blackfox_restapi.models.input_config import InputConfig
from blackfox_restapi.models.input_window_config import InputWindowConfig
from blackfox_restapi.models.input_window_range_config import InputWindowRangeConfig
from blackfox_restapi.models.keras_hidden_layer_config import KerasHiddenLayerConfig
from blackfox_restapi.models.keras_layer_config import KerasLayerConfig
from blackfox_restapi.models.keras_optimization_config import KerasOptimizationConfig
from blackfox_restapi.models.keras_optimization_status import KerasOptimizationStatus
from blackfox_restapi.models.keras_optimized_network import KerasOptimizedNetwork
from blackfox_restapi.models.keras_recurrent_hidden_layer_config import KerasRecurrentHiddenLayerConfig
from blackfox_restapi.models.keras_recurrent_optimization_config import KerasRecurrentOptimizationConfig
from blackfox_restapi.models.keras_recurrent_optimization_status import KerasRecurrentOptimizationStatus
from blackfox_restapi.models.keras_recurrent_optimized_network import KerasRecurrentOptimizedNetwork
from blackfox_restapi.models.keras_series_optimization_config import KerasSeriesOptimizationConfig
from blackfox_restapi.models.keras_series_training_config import KerasSeriesTrainingConfig
from blackfox_restapi.models.keras_training_config import KerasTrainingConfig
from blackfox_restapi.models.optimization_engine_config import OptimizationEngineConfig
from blackfox_restapi.models.output_window_config import OutputWindowConfig
from blackfox_restapi.models.prediction_array_config import PredictionArrayConfig
from blackfox_restapi.models.prediction_file_config import PredictionFileConfig
from blackfox_restapi.models.range import Range
from blackfox_restapi.models.recurrent_optimization_engine_config import RecurrentOptimizationEngineConfig
from blackfox_restapi.models.trained_network import TrainedNetwork

from blackfox.black_fox import BlackFox
from blackfox.log_writer import LogWriter
from blackfox.csv_log_writer import CsvLogWriter